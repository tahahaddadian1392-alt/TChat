# TChat setup
1. Supabase: create project → SQL Editor → run supabase/schema.sql
2. Authentication → Providers → Email: turn OFF "Confirm email"
3. Storage: create PUBLIC bucket `media`, then run the storage policy line at the end of schema.sql
4. Put URL + anon key in lib/main.dart
5. `flutter create .` (inside this folder, keeps lib/ and pubspec.yaml) then add to android/app/src/main/AndroidManifest.xml:
   INTERNET, RECORD_AUDIO permissions
6. `flutter pub get && flutter run`
