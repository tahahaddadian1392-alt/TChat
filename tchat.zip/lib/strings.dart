const _s = {
  'fa': {
    'login': 'ورود', 'signup': 'ثبت‌نام', 'userid': 'آیدی کاربری', 'pass': 'رمز عبور',
    'taken': 'این آیدی وجود دارد، یکی دیگر انتخاب کن', 'settings': 'تنظیمات',
    'theme': 'تم', 'mode': 'حالت نمایش', 'auto': 'خودکار', 'light': 'روشن', 'dark': 'تیره',
    'turq': 'فیروزه‌ای', 'proTitle': 'TChat Pro', 'proMsg': 'برای استفاده از این رنگ باید اشتراک Pro بخری.',
    'support': 'پشتیبانی', 'close': 'بستن', 'msg': 'پیام...', 'newchat': 'چت جدید (آیدی)',
    'newgroup': 'گروه جدید', 'lang': 'زبان', 'pass6': 'رمز ۶ رقمی', 'ok': 'تأیید',
  },
  'en': {
    'login': 'Log in', 'signup': 'Sign up', 'userid': 'User ID', 'pass': 'Password',
    'taken': 'This ID is taken, choose another', 'settings': 'Settings',
    'theme': 'Theme', 'mode': 'Appearance', 'auto': 'Auto', 'light': 'Light', 'dark': 'Dark',
    'turq': 'Turquoise', 'proTitle': 'TChat Pro', 'proMsg': 'You need a Pro subscription to use this color.',
    'support': 'Support', 'close': 'Close', 'msg': 'Message...', 'newchat': 'New chat (ID)',
    'newgroup': 'New group', 'lang': 'Language', 'pass6': '6-digit code', 'ok': 'OK',
  },
};
String tr(String lang, String k) => _s[lang]![k] ?? k;
