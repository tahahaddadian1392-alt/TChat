import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart' as fgt;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'screens.dart';

/// نوتیفیکیشن + وضعیت اتصال + آنلاین بودن کاربران.
/// سه لایه برای رسیدن پیام: Realtime، پولینگ هر ۸ ثانیه (حتی وقتی برنامه بیرونه)، و سرویس پیش‌زمینه که پروسه رو زنده نگه می‌داره.
class Notifier with WidgetsBindingObserver {
  Notifier._();
  static final Notifier I = Notifier._();

  /// آیا به سرور وصلیم؟ (برای نوشته‌ی Connecting... بالای برنامه)
  final conn = ValueNotifier<bool>(false);
  /// آیدی کاربرانی که الان آنلاین و وصل به سرور هستن
  final online = ValueNotifier<Set<String>>({});
  /// با هر پیام جدید زیاد می‌شه؛ لیست چت‌ها به‌روز بشه
  final ticks = ValueNotifier<int>(0);

  final _np = FlutterLocalNotificationsPlugin();
  RealtimeChannel? _ch, _pc;
  Timer? _poll;
  bool _ready = false, _fg = true, _busy = false;
  bool _chOk = false, _pollOk = false;
  int _chBad = 0, _pcBad = 0;
  bool _pcOk = false;
  String? _openChat;
  final _names = <String, String>{};
  final _titles = <String, String>{};
  final _groups = <String>{};
  final _lines = <String, List<String>>{};
  final _shown = <String>{};

  int _nid(String chatId) => chatId.hashCode & 0x7fffffff;
  void _upd() => conn.value = _chOk && _pollOk;

  // آخرین پیامی که پردازش شده (همیشه فقط جلو می‌ره؛ به ساعت گوشی وابسته نیست)
  void _advance(String? ts) {
    final t = DateTime.tryParse(ts ?? '');
    if (t == null) return;
    final cur = DateTime.tryParse(app.p.getString('last_seen') ?? '');
    if (cur == null || t.isAfter(cur)) app.p.setString('last_seen', t.toUtc().toIso8601String());
  }

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    WidgetsBinding.instance.addObserver(this);
    await _np.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (r) {
        final parts = (r.payload ?? '').split('|');
        if (parts.length < 2) return;
        navKey.currentState?.push(MaterialPageRoute(
            builder: (_) => ChatScreen(chatId: parts[0], title: parts.sublist(1).join('|'))));
      },
    );
    // اول وصل شو، بعد سراغ دیالوگ‌های دسترسی برو
    _listen();
    _presence();
    _poll ??= Timer.periodic(const Duration(seconds: 8), (_) => _tick());
    _catchUp();
    if (!(app.p.getBool('notif_asked') ?? false)) {
      await app.p.setBool('notif_asked', true);
      await Permission.notification.request();
    }
    if (app.p.getBool('reliable') ?? true) await setReliable(true);
  }

  // اتصال مطمئن: سرویس پیش‌زمینه تا اندروید برنامه رو نبنده
  Future<void> setReliable(bool on) async {
    await app.p.setBool('reliable', on);
    try {
      if (on) {
        fgt.FlutterForegroundTask.init(
          androidNotificationOptions: fgt.AndroidNotificationOptions(
            channelId: 'tchat_service',
            channelName: 'TChat connection',
            channelImportance: fgt.NotificationChannelImportance.LOW,
            priority: fgt.NotificationPriority.LOW,
          ),
          iosNotificationOptions: const fgt.IOSNotificationOptions(),
          foregroundTaskOptions: fgt.ForegroundTaskOptions(
            eventAction: fgt.ForegroundTaskEventAction.nothing(),
            allowWakeLock: true,
            allowWifiLock: true,
          ),
        );
        if (!await fgt.FlutterForegroundTask.isRunningService) {
          await fgt.FlutterForegroundTask.startService(
              serviceId: 777, notificationTitle: 'TChat', notificationText: app.t('svcText'));
        }
      } else {
        await fgt.FlutterForegroundTask.stopService();
      }
    } catch (_) {}
  }

  // هر ۸ ثانیه، چه داخل برنامه چه بیرون: پیام جدید رو چک کن + اتصال‌ها رو سالم نگه دار
  void _tick() {
    if (sb.auth.currentUser == null) return;
    if (!_chOk && ++_chBad >= 2) { _chBad = 0; _listen(); }
    if (_chOk) _chBad = 0;
    if (!_pcOk && ++_pcBad >= 2) { _pcBad = 0; _presence(); }
    if (_pcOk) _pcBad = 0;
    _catchUp();
  }

  void _listen() {
    if (_ch != null) sb.removeChannel(_ch!);
    _chOk = false; _upd();
    _ch = sb
        .channel('tchat-inbox')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          callback: (p) => _handle(Map<String, dynamic>.from(p.newRecord)),
        )
        .subscribe((status, err) {
      _chOk = status == RealtimeSubscribeStatus.subscribed;
      _upd();
      if (_chOk) _catchUp(); // هرچی تو فاصله‌ی قطعی رسیده رو بگیر
    });
  }

  // آنلاین بودن: هر کسی که به سرور وصله خودش رو در این کانال ثبت می‌کنه
  void _presence() {
    final me = sb.auth.currentUser?.id;
    if (me == null) return;
    if (_pc != null) sb.removeChannel(_pc!);
    _pcOk = false;
    final ch = sb.channel('presence-global', opts: RealtimeChannelConfig(key: me));
    _pc = ch;
    ch.onPresenceSync((_) => _syncPresence(ch)).subscribe((status, err) async {
      _pcOk = status == RealtimeSubscribeStatus.subscribed;
      if (_pcOk) { try { await ch.track({'uid': me}); } catch (_) {} }
    });
  }

  void _syncPresence(RealtimeChannel ch) {
    final s = <String>{};
    try {
      final raw = (ch as dynamic).presenceState();
      if (raw is Map) {
        for (final k in raw.keys) { s.add('$k'); }
      } else if (raw is Iterable) {
        for (final st in raw) {
          final k = (st as dynamic).key;
          if (k is String && k.isNotEmpty) s.add(k);
          try {
            for (final p in (st as dynamic).presences) {
              final u = (p as dynamic).payload['uid'];
              if (u is String) s.add(u);
            }
          } catch (_) {}
        }
      }
    } catch (_) {}
    online.value = s;
  }

  Future<void> _handle(Map<String, dynamic> m) async {
    _advance(m['created_at'] as String?);
    final id = '${m['id']}';
    if (_shown.contains(id)) return;
    if (_shown.length > 500) _shown.clear();
    _shown.add(id);
    ticks.value++;
    if (m['sender'] == sb.auth.currentUser?.id) return;
    if (_fg && _openChat == m['chat_id']) return;
    await _show(m);
  }

  // پیام‌هایی که از آخرین بررسی رسیدن (پولینگ + جبران قطعی)
  Future<void> _catchUp() async {
    if (_busy) return;
    final me = sb.auth.currentUser?.id;
    if (me == null) return;
    _busy = true;
    try {
      final last = app.p.getString('last_seen');
      if (last == null) {
        final r = await sb.from('messages').select('created_at').order('created_at', ascending: false).limit(1);
        _advance(r.isEmpty ? DateTime.now().toUtc().toIso8601String() : r.first['created_at'] as String?);
      } else {
        final rows = await sb.from('messages').select().gt('created_at', last).order('created_at').limit(50);
        for (final r in rows) { await _handle(Map<String, dynamic>.from(r)); }
      }
      _pollOk = true;
    } catch (_) {
      _pollOk = false;
    } finally {
      _busy = false;
      _upd();
    }
  }

  Future<void> _show(Map<String, dynamic> m) async {
    try {
      final chatId = m['chat_id'] as String;
      final sid = m['sender'] as String;
      if (!_names.containsKey(sid)) {
        final p = await sb.from('profiles').select('user_id').eq('id', sid).single();
        _names[sid] = p['user_id'] as String;
      }
      final who = _names[sid]!;
      if (!_titles.containsKey(chatId)) {
        final c = await sb.from('chats').select('type,title').eq('id', chatId).single();
        if (c['type'] == 'group') _groups.add(chatId);
        _titles[chatId] = c['type'] == 'group' ? (c['title'] ?? 'Group') : who;
      }
      final title = _titles[chatId]!;
      final k = m['kind'];
      final body = k == 'text' ? (m['body'] ?? '')
          : k == 'image' ? app.t('kImage')
          : k == 'voice' ? app.t('kVoice')
          : k == 'video' ? app.t('kVideo')
          : '📄 ${m['body'] ?? ''}';
      final list = _lines.putIfAbsent(chatId, () => []);
      list.add(_groups.contains(chatId) ? '$who: $body' : '$body');
      if (list.length > 6) list.removeAt(0);
      await _np.show(
        _nid(chatId), title, list.last,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'tchat_messages', 'Messages',
            channelDescription: 'New messages',
            importance: Importance.high,
            priority: Priority.high,
            category: AndroidNotificationCategory.message,
            groupKey: 'tchat',
            number: list.length,
            styleInformation: InboxStyleInformation(List<String>.from(list),
                contentTitle: title, summaryText: '${list.length}'),
          ),
        ),
        payload: '$chatId|$title',
      );
    } catch (_) {}
  }

  void openChat(String id) {
    _openChat = id;
    _lines.remove(id);
    _np.cancel(_nid(id));
  }

  void closeChat() => _openChat = null;

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    _fg = s == AppLifecycleState.resumed;
    if (_fg) { _listen(); _presence(); _catchUp(); }
  }
}
