import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart' as fgt;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'screens.dart';

/// نوتیفیکیشن پیام‌ها: Realtime + همگام‌سازی جاافتاده‌ها + سرویس پیش‌زمینه
class Notifier with WidgetsBindingObserver {
  Notifier._();
  static final Notifier I = Notifier._();

  final _np = FlutterLocalNotificationsPlugin();
  RealtimeChannel? _ch;
  bool _ready = false, _fg = true;
  String? _openChat;
  final _names = <String, String>{};
  final _titles = <String, String>{};
  final _groups = <String>{};
  final _lines = <String, List<String>>{};

  int _nid(String chatId) => chatId.hashCode & 0x7fffffff;
  void _seen([String? ts]) =>
      app.p.setString('last_seen', ts ?? DateTime.now().toUtc().toIso8601String());

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    WidgetsBinding.instance.addObserver(this);
    await _np.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (r) {
        final parts = (r.payload ?? '').split('|');
        if (parts.length < 2) return;
        navKey.currentState?.push(MaterialPageRoute(
            builder: (_) => ChatScreen(chatId: parts[0], title: parts.sublist(1).join('|'))));
      },
    );
    if (!(app.p.getBool('notif_asked') ?? false)) {
      await app.p.setBool('notif_asked', true);
      await Permission.notification.request();
    }
    if (app.p.getBool('reliable') ?? true) await setReliable(true);
    await _catchUp();
    _listen();
  }

  // اتصال مطمئن: سرویس پیش‌زمینه تا اندروید برنامه رو نبنده
  Future<void> setReliable(bool on) async {
    await app.p.setBool('reliable', on);
    try {
      if (on) {
        fgt.FlutterForegroundTask.init(
          androidNotificationOptions: fgt.AndroidNotificationOptions(
            channelId: 'tchat_service',
            channelName: 'TChat connection',
            channelImportance: fgt.NotificationChannelImportance.LOW,
            priority: fgt.NotificationPriority.LOW,
          ),
          iosNotificationOptions: const fgt.IOSNotificationOptions(),
          foregroundTaskOptions: fgt.ForegroundTaskOptions(
            eventAction: fgt.ForegroundTaskEventAction.nothing(),
            allowWakeLock: true,
            allowWifiLock: true,
          ),
        );
        if (!await fgt.FlutterForegroundTask.isRunningService) {
          await fgt.FlutterForegroundTask.startService(
              serviceId: 777, notificationTitle: 'TChat', notificationText: app.t('svcText'));
        }
      } else {
        await fgt.FlutterForegroundTask.stopService();
      }
    } catch (_) {}
  }

  void _listen() {
    if (_ch != null) sb.removeChannel(_ch!);
    _ch = sb
        .channel('tchat-inbox')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          callback: (p) => _onRow(Map<String, dynamic>.from(p.newRecord)),
        )
        .subscribe();
  }

  Future<void> _onRow(Map<String, dynamic> m) async {
    _seen(m['created_at'] as String?);
    if (m['sender'] == sb.auth.currentUser?.id) return;
    if (_fg && _openChat == m['chat_id']) return;
    await _show(m);
  }

  // پیام‌هایی که وقتی اتصال قطع بود رسیدن
  Future<void> _catchUp() async {
    final me = sb.auth.currentUser?.id;
    if (me == null) return;
    final last = app.p.getString('last_seen');
    final now = DateTime.now().toUtc().toIso8601String();
    if (last == null) { _seen(now); return; }
    try {
      final rows = await sb.from('messages').select().gt('created_at', last)
          .neq('sender', me).order('created_at').limit(20);
      for (final r in rows) {
        if (_fg && _openChat == r['chat_id']) continue;
        await _show(Map<String, dynamic>.from(r));
      }
      _seen(now);
    } catch (_) {}
  }

  Future<void> _show(Map<String, dynamic> m) async {
    try {
      final chatId = m['chat_id'] as String;
      final sid = m['sender'] as String;
      if (!_names.containsKey(sid)) {
        final p = await sb.from('profiles').select('user_id').eq('id', sid).single();
        _names[sid] = p['user_id'] as String;
      }
      final who = _names[sid]!;
      if (!_titles.containsKey(chatId)) {
        final c = await sb.from('chats').select('type,title').eq('id', chatId).single();
        if (c['type'] == 'group') _groups.add(chatId);
        _titles[chatId] = c['type'] == 'group' ? (c['title'] ?? 'Group') : who;
      }
      final title = _titles[chatId]!;
      final k = m['kind'];
      final body = k == 'text' ? (m['body'] ?? '')
          : k == 'image' ? app.t('kImage')
          : k == 'voice' ? app.t('kVoice')
          : k == 'video' ? app.t('kVideo')
          : '📄 ${m['body'] ?? ''}';
      final list = _lines.putIfAbsent(chatId, () => []);
      list.add(_groups.contains(chatId) ? '$who: $body' : '$body');
      if (list.length > 6) list.removeAt(0);
      await _np.show(
        _nid(chatId), title, list.last,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'tchat_messages', 'Messages',
            channelDescription: 'New messages',
            importance: Importance.high,
            priority: Priority.high,
            category: AndroidNotificationCategory.message,
            groupKey: 'tchat',
            number: list.length,
            styleInformation: InboxStyleInformation(List<String>.from(list),
                contentTitle: title, summaryText: '${list.length}'),
          ),
        ),
        payload: '$chatId|$title',
      );
    } catch (_) {}
  }

  void openChat(String id) {
    _openChat = id;
    _lines.remove(id);
    _np.cancel(_nid(id));
  }

  void closeChat() => _openChat = null;

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    _fg = s == AppLifecycleState.resumed;
    if (s == AppLifecycleState.paused) _seen();
    if (_fg) { _catchUp(); _listen(); }
  }
}
