import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens.dart';
import 'strings.dart';

final sb = Supabase.instance.client;
const turquoise = Color(0xFF14D6C4); // فیروزه‌ای اصلی؛ گرادیان با آبی در AppBar

class AppState extends ChangeNotifier {
  ThemeMode mode = ThemeMode.system;
  bool turq = false;
  String lang = 'fa';
  Map<String, dynamic>? me;
  late SharedPreferences p;

  Future<void> init() async {
    p = await SharedPreferences.getInstance();
    mode = ThemeMode.values[p.getInt('mode') ?? 0];
    turq = p.getBool('turq') ?? false;
    lang = p.getString('lang') ?? 'fa';
    await refreshMe();
  }

  Future<void> refreshMe() async {
    final u = sb.auth.currentUser;
    if (u == null) { me = null; notifyListeners(); return; }
    me = await sb.from('profiles').select().eq('id', u.id).single();
    if (!isPro && turq) { turq = false; p.setBool('turq', false); } // اشتراک غیرفعال شد
    notifyListeners();
  }

  bool get isPro => me?['is_pro'] == true || me?['role'] == 'owner';
  String get role => me?['role'] ?? 'user';
  void setMode(ThemeMode m) { mode = m; p.setInt('mode', m.index); notifyListeners(); }
  void setTurq(bool v) { turq = v; p.setBool('turq', v); notifyListeners(); }
  void setLang(String l) { lang = l; p.setString('lang', l); notifyListeners(); }
  String t(String k) => tr(lang, k);
}

final app = AppState();
final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
      url: 'https://pbtbnrtgngyrotitshup.supabase.co',
      anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBidGJucnRnbmd5cm90aXRzaHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM0MTQxNzEsImV4cCI6MjEwODk5MDE3MX0.6gQkRgsN4jzHA-loStu1l32TJeSnY2EacNAifF3XneA');
  await app.init();
  runApp(const TChat());
}

class TChat extends StatelessWidget {
  const TChat({super.key});
  ThemeData _theme(Brightness b) {
    final seed = app.turq ? turquoise : const Color(0xFF2A7DE1);
    return ThemeData(useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: b));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (_, __) => MaterialApp(
          navigatorKey: navKey,
          title: 'TChat',
          themeMode: app.mode,
          theme: _theme(Brightness.light),
          darkTheme: _theme(Brightness.dark),
          locale: Locale(app.lang),
          supportedLocales: const [Locale('fa'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: sb.auth.currentUser == null ? const AuthScreen() : const HomeScreen(),
        ),
      );
}
