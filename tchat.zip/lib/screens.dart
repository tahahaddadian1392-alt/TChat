import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'notifications.dart';
import 'main.dart';

/// آواتار مشترک: عکس پروفایل، و در نبودش (یا خطا) حرف اول اسم / آیکن
class Avatar extends StatelessWidget {
  final String? url, name;
  final bool group;
  final double r;
  const Avatar({super.key, this.url, this.name, this.group = false, this.r = 20});

  @override
  Widget build(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    final fallback = CircleAvatar(
      radius: r, backgroundColor: cs.secondaryContainer, foregroundColor: cs.onSecondaryContainer,
      child: group ? Icon(Icons.group, size: r)
          : (name != null && name!.isNotEmpty) ? Text(name![0].toUpperCase(), style: TextStyle(fontSize: r * .9))
          : Icon(Icons.person, size: r));
    if (url == null || url!.isEmpty) return fallback;
    return SizedBox(width: r * 2, height: r * 2, child: ClipOval(child: Image.network(url!,
        fit: BoxFit.cover, gaplessPlayback: true,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (_, child, p) => p == null ? child : fallback)));
  }
}

String _email(String id) => '${id.toLowerCase()}@tchat.app';

// ---------- ورود / ثبت‌نام ----------
class AuthScreen extends StatefulWidget { const AuthScreen({super.key}); @override State<AuthScreen> createState() => _A(); }
class _A extends State<AuthScreen> {
  final id = TextEditingController(), pw = TextEditingController();
  bool signup = false; String? err;

  Future<void> go() async {
    try {
      if (signup) {
        if (await sb.rpc('user_id_exists', params: {'u': id.text.trim()})) {
          setState(() => err = app.t('taken')); return;
        }
        await sb.auth.signUp(email: _email(id.text.trim()), password: pw.text,
            data: {'user_id': id.text.trim()});
      } else {
        await sb.auth.signInWithPassword(email: _email(id.text.trim()), password: pw.text);
      }
      await app.refreshMe();
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) { setState(() => err = e.toString()); }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 110, height: 110)),
          const SizedBox(height: 24),
          TextField(controller: id, decoration: InputDecoration(labelText: app.t('userid'))),
          TextField(controller: pw, obscureText: true, decoration: InputDecoration(labelText: app.t('pass'))),
          if (err != null) Padding(padding: const EdgeInsets.all(8), child: Text(err!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: go, child: Text(app.t(signup ? 'signup' : 'login'))),
          TextButton(onPressed: () => setState(() => signup = !signup), child: Text(app.t(signup ? 'login' : 'signup'))),
        ])),
      );
}

// ---------- لیست چت‌ها ----------
class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _H(); }
class _H extends State<HomeScreen> {
  bool held = false, combo = false; int taps = 0; DateTime last = DateTime(2000);
  List<Map<String, dynamic>> chats = [];

  @override
  void initState() {
    super.initState();
    load();
    WidgetsBinding.instance.addPostFrameCallback((_) async { await askBattery(); await Notifier.I.init(); });
  }

  // اولین اجرا: درخواست برداشتن محدودیت باتری
  Future<void> askBattery() async {
    if (app.p.getBool('battery_asked') ?? false) return;
    await app.p.setBool('battery_asked', true);
    if (!mounted) return;
    final go = await showDialog<bool>(context: context, barrierDismissible: false, builder: (c) => AlertDialog(
      icon: const Icon(Icons.battery_charging_full),
      title: Text(app.t('batTitle')), content: Text(app.t('batMsg')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(app.t('later'))),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(app.t('batBtn'))),
      ]));
    if (go == true) await Permission.ignoreBatteryOptimizations.request();
  }

  Future<void> load() async {
    try {
    final r = await sb.from('chats').select('id,type,title,chat_members(profiles(id,user_id,display_name,avatar_url))');
    if (mounted) setState(() => chats = List<Map<String, dynamic>>.from(r));
    } catch (_) {}
  }

  // پروفایل طرف مقابل در چت خصوصی
  Map? other(Map c) {
    if (c['type'] == 'group') return null;
    final me = sb.auth.currentUser?.id;
    for (final e in (c['chat_members'] as List)) {
      final p = e['profiles'];
      if (p != null && p['id'] != me) return p;
    }
    return null;
  }

  String name(Map c) {
    if (c['type'] == 'group') return c['title'] ?? 'Group';
    return other(c)?['user_id'] ?? '?';
  }

  // مخفی: نگه داشتن تنظیمات + سه ضربه روی عکس پروفایل
  void avatarTap() {
    if (!held) return;
    final now = DateTime.now();
    taps = now.difference(last).inSeconds < 2 ? taps + 1 : 1;
    last = now;
    if (taps >= 3) { taps = 0; combo = true; askCode(); }
  }

  Future<void> askCode() async {
    final ctl = TextEditingController();
    final code = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      content: TextField(controller: ctl, keyboardType: TextInputType.number, maxLength: 6,
          obscureText: true, decoration: InputDecoration(labelText: app.t('pass6'))),
      actions: [TextButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(app.t('ok')))]));
    if (code == null) return;
    String msg;
    try {
      final r = await sb.rpc('claim_owner', params: {'pass': code});
      await app.refreshMe();
      msg = r == 'ok' ? app.t('owned') : r == 'locked' ? app.t('locked')
          : r == 'owner_exists' ? app.t('ownerExists') : app.t('wrongCode');
    } catch (e) { msg = e.toString(); }
    if (mounted) { setState(() {}); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg))); }
  }

  Future<void> newChat() async {
    final ctl = TextEditingController();
    final id = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      content: TextField(controller: ctl, decoration: InputDecoration(labelText: app.t('newchat'))),
      actions: [TextButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(app.t('ok')))]));
    if (id == null || id.isEmpty) return;
    final cid = await sb.rpc('get_or_create_direct', params: {'other': id.trim()});
    if (mounted) await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: cid, title: id)));
    load();
  }

  @override
  Widget build(BuildContext c) {
    final av = app.me?['avatar_url'];
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(
            colors: app.turq ? [turquoise, const Color(0xFF2A7DE1)] : [Theme.of(c).colorScheme.primaryContainer, Theme.of(c).colorScheme.primaryContainer]))),
        title: const Text('TChat'),
        leading: Padding(padding: const EdgeInsets.all(8), child: GestureDetector(onTap: avatarTap,
            child: Avatar(url: av, name: app.me?['user_id'], r: 20))),
        actions: [
          Listener(
            onPointerDown: (_) { held = true; combo = false; },
            onPointerUp: (_) => held = false,
            onPointerCancel: (_) => held = false,
            child: IconButton(icon: const Icon(Icons.settings),
                onPressed: () async { if (combo) { combo = false; return; } await Navigator.push(c, MaterialPageRoute(builder: (_) => const SettingsScreen())); setState(() {}); }),
          ),
        ],
      ),
      body: RefreshIndicator(onRefresh: load, child: ListView(children: [
        for (final ch in chats) ListTile(
          leading: Avatar(url: other(ch)?['avatar_url'], name: name(ch), group: ch['type'] == 'group', r: 24),
          title: Text(name(ch)),
          onTap: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => ChatScreen(chatId: ch['id'], title: name(ch)))); load(); },
        )
      ])),
      floatingActionButton: FloatingActionButton(onPressed: newChat, child: const Icon(Icons.edit)),
    );
  }
}

// ---------- تنظیمات و تم ----------
class SettingsScreen extends StatefulWidget { const SettingsScreen({super.key}); @override State<SettingsScreen> createState() => _S(); }
class _S extends State<SettingsScreen> {
  @override
  void initState() { super.initState(); app.refreshMe().then((_) { if (mounted) setState(() {}); }); }

  Future<void> pickAvatar() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 512);
      if (x == null) return;
      final path = 'avatars/${sb.auth.currentUser!.id}.jpg';
      await sb.storage.from('media').upload(path, File(x.path), fileOptions: const FileOptions(upsert: true));
      final url = sb.storage.from('media').getPublicUrl(path);
      await sb.from('profiles').update({'avatar_url': '$url?t=${DateTime.now().millisecondsSinceEpoch}'}).eq('id', sb.auth.currentUser!.id);
      await app.refreshMe(); if (mounted) setState(() {});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Future<void> proDialog() async => showDialog(context: context, builder: (c) => AlertDialog(
        title: Text(app.t('proTitle')), content: Text(app.t('proMsg')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(app.t('close'))),
          FilledButton.icon(icon: const Icon(Icons.support_agent), label: Text(app.t('support')), onPressed: () async {
            Navigator.pop(c);
            final owner = await sb.rpc('get_owner_user_id');
            if (owner == null) return;
            final cid = await sb.rpc('get_or_create_direct', params: {'other': owner});
            if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: cid, title: owner)));
          }),
        ]));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(app.t('settings'))),
        body: ListView(children: [
          ListTile(leading: Avatar(url: app.me?['avatar_url'], name: app.me?['user_id'], r: 22), title: Text(app.me?['user_id'] ?? ''), trailing: const Icon(Icons.photo_camera), onTap: pickAvatar),
          ListTile(title: Text(app.t('mode'))),
          RadioListTile(title: Text(app.t('auto')), value: ThemeMode.system, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          RadioListTile(title: Text(app.t('light')), value: ThemeMode.light, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          RadioListTile(title: Text(app.t('dark')), value: ThemeMode.dark, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          const Divider(),
          ListTile(title: Text(app.t('theme'))),
          ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFF2A7DE1)),
            title: const Text('Classic'), trailing: app.turq ? null : const Icon(Icons.check),
            onTap: () { app.setTurq(false); setState(() {}); }),
          ListTile(
            leading: Container(width: 40, height: 40, decoration: const BoxDecoration(shape: BoxShape.circle,
                gradient: LinearGradient(colors: [turquoise, Color(0xFF2A7DE1)]))),
            title: Text(app.t('turq')),
            trailing: app.isPro ? (app.turq ? const Icon(Icons.check) : null) : const Icon(Icons.lock),
            onTap: () { if (app.isPro) { app.setTurq(true); setState(() {}); } else { proDialog(); } }),
          const Divider(),
          SwitchListTile(secondary: const Icon(Icons.notifications_active), title: Text(app.t('relTitle')),
              subtitle: Text(app.t('relSub')), value: app.p.getBool('reliable') ?? true,
              onChanged: (v) async { await Notifier.I.setReliable(v); setState(() {}); }),
          ListTile(leading: const Icon(Icons.battery_charging_full), title: Text(app.t('batSetting')),
              onTap: () => Permission.ignoreBatteryOptimizations.request()),
          ListTile(title: Text(app.t('lang')), trailing: Text(app.lang == 'fa' ? 'فارسی' : 'English'),
              onTap: () { app.setLang(app.lang == 'fa' ? 'en' : 'fa'); setState(() {}); }),
        ]),
      );
}

// ---------- صفحه چت ----------
class ChatScreen extends StatefulWidget {
  final String chatId, title;
  const ChatScreen({super.key, required this.chatId, required this.title});
  @override State<ChatScreen> createState() => _C();
}
class _C extends State<ChatScreen> with WidgetsBindingObserver {
  final ctl = TextEditingController();
  final rec = AudioRecorder();
  bool recording = false, isGroup = false;
  List<Map<String, dynamic>> msgs = []; // قدیمی‌ترین ← جدیدترین
  final members = <String, Map<String, dynamic>>{};
  StreamSubscription? _sub;
  Timer? _retry;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Notifier.I.openChat(widget.chatId);
    _loadMembers();
    _subscribe();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel(); _retry?.cancel();
    Notifier.I.closeChat();
    ctl.dispose(); rec.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _subscribe(); // اتصال بعد از بک‌گراند دوباره برقرار شه
  }

  Future<void> _loadMembers() async {
    try {
      final ch = await sb.from('chats').select('type').eq('id', widget.chatId).single();
      final r = await sb.from('chat_members')
          .select('profiles(id,user_id,display_name,avatar_url)').eq('chat_id', widget.chatId);
      if (!mounted) return;
      setState(() {
        isGroup = ch['type'] == 'group';
        for (final e in r) {
          final p = e['profiles'];
          if (p != null) members[p['id']] = Map<String, dynamic>.from(p);
        }
      });
    } catch (_) {}
  }

  // به‌جای StreamBuilder: لیست آخرین داده رو نگه می‌داریم تا هنگام قطع/وصل شدن خالی و پرش نکنه
  void _subscribe() {
    _retry?.cancel();
    _sub?.cancel();
    _sub = sb.from('messages').stream(primaryKey: ['id']).eq('chat_id', widget.chatId).order('created_at').listen(
      (rows) { if (mounted) setState(() => msgs = _sorted(rows)); },
      onError: (_) { _retry = Timer(const Duration(seconds: 2), () { if (mounted) _subscribe(); }); },
    );
  }

  List<Map<String, dynamic>> _sorted(List rows) {
    final l = rows.map((e) => Map<String, dynamic>.from(e)).toList();
    DateTime t(Map m) => DateTime.tryParse('${m['created_at']}') ?? DateTime.fromMillisecondsSinceEpoch(0);
    l.sort((a, b) {
      final c = t(a).compareTo(t(b));
      return c != 0 ? c : '${a['id']}'.compareTo('${b['id']}');
    });
    return l;
  }

  Map<String, dynamic>? get otherMember {
    final me = sb.auth.currentUser?.id;
    for (final p in members.values) { if (p['id'] != me) return p; }
    return null;
  }

  void _err(Object e) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
  }

  Future<void> send(String kind, {String? body, String? url}) async {
    try {
      await sb.rpc('send_message', params: {'p_chat': widget.chatId, 'p_kind': kind, 'p_body': body, 'p_url': url});
      if (kind == 'text') await app.refreshMe(); // اگه پیام خاص بود وضعیت خودم هم به‌روز بشه
    } catch (e) { _err(e); }
  }

  Future<void> sendText() async {
    final t = ctl.text.trim(); if (t.isEmpty) return;
    ctl.clear(); await send('text', body: t);
  }

  Future<String> upload(File f, String name) async {
    final path = '${widget.chatId}/${DateTime.now().millisecondsSinceEpoch}_$name';
    await sb.storage.from('media').upload(path, f);
    return sb.storage.from('media').getPublicUrl(path);
  }

  Future<void> attach() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      if (r == null) return;
      final f = r.files.single; final ext = (f.extension ?? '').toLowerCase();
      final kind = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext) ? 'image'
          : ['mp4', 'mov', 'mkv', 'webm'].contains(ext) ? 'video' : 'file';
      await send(kind, body: f.name, url: await upload(File(f.path!), f.name));
    } catch (e) { _err(e); }
  }

  Future<void> toggleVoice() async {
    try {
      if (!recording) {
        if (!await rec.hasPermission()) return;
        final dir = await getTemporaryDirectory();
        await rec.start(const RecordConfig(), path: '${dir.path}/v_${DateTime.now().millisecondsSinceEpoch}.m4a');
        setState(() => recording = true);
      } else {
        final p = await rec.stop(); setState(() => recording = false);
        if (p != null) await send('voice', url: await upload(File(p), 'voice.m4a'));
      }
    } catch (e) { setState(() => recording = false); _err(e); }
  }

  String _time(dynamic s) {
    final d = DateTime.tryParse('$s')?.toLocal();
    if (d == null) return '';
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  Widget _image(String? url) {
    const size = 220.0; // اندازه ثابت: بدون پرش چیدمان هنگام لود شدن عکس
    final box = Container(width: size, height: size, color: Colors.black12,
        child: const Icon(Icons.image_not_supported_outlined));
    if (url == null) return box;
    return ClipRRect(borderRadius: BorderRadius.circular(8), child: SizedBox(width: size, height: size,
        child: Image.network(url, fit: BoxFit.cover, gaplessPlayback: true,
            errorBuilder: (_, __, ___) => box,
            loadingBuilder: (_, child, p) => p == null ? child
                : Container(color: Colors.black12, alignment: Alignment.center, child: const CircularProgressIndicator(strokeWidth: 2)))));
  }

  Widget bubble(Map m) {
    final mine = m['sender'] == sb.auth.currentUser!.id;
    final k = m['kind'];
    final prof = members[m['sender']];
    final cs = Theme.of(context).colorScheme;
    final Widget content = k == 'text' ? Text(m['body'] ?? '')
        : k == 'image' ? _image(m['media_url'])
        : Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(k == 'voice' ? Icons.mic : k == 'video' ? Icons.videocam : Icons.insert_drive_file),
            const SizedBox(width: 6), Flexible(child: Text(m['body'] ?? k))]);
    final box = ConstrainedBox(
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .72),
      child: Container(padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
          decoration: BoxDecoration(color: mine ? cs.primaryContainer : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(14)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            if (!mine && isGroup && prof != null)
              Padding(padding: const EdgeInsets.only(bottom: 2),
                  child: Text(prof['user_id'] ?? '', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: cs.primary))),
            content,
            Padding(padding: const EdgeInsets.only(top: 3),
                child: Text(_time(m['created_at']), style: TextStyle(fontSize: 10, color: cs.onSurfaceVariant))),
          ])),
    );
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        child: Row(mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end, children: [
          if (!mine) ...[Avatar(url: prof?['avatar_url'], name: prof?['user_id'], r: 15), const SizedBox(width: 6)],
          Flexible(child: box),
        ]));
  }

  @override
  Widget build(BuildContext c) {
    final o = otherMember;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Avatar(url: isGroup ? null : o?['avatar_url'], name: widget.title, group: isGroup, r: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(widget.title, overflow: TextOverflow.ellipsis)),
      ])),
      body: Column(children: [
        Expanded(child: ListView.builder(
          reverse: true, // جدیدترین پیام پایین، و همیشه به پایین چسبیده
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: msgs.length,
          findChildIndexCallback: (key) {
            final id = (key as ValueKey).value;
            final i = msgs.indexWhere((m) => m['id'] == id);
            return i < 0 ? null : msgs.length - 1 - i;
          },
          itemBuilder: (_, i) {
            final m = msgs[msgs.length - 1 - i];
            return KeyedSubtree(key: ValueKey(m['id']), child: bubble(m));
          },
        )),
        SafeArea(child: Row(children: [
          IconButton(icon: const Icon(Icons.attach_file), onPressed: attach),
          Expanded(child: TextField(controller: ctl, decoration: InputDecoration(hintText: app.t('msg')), onSubmitted: (_) => sendText())),
          IconButton(icon: Icon(recording ? Icons.stop_circle : Icons.mic, color: recording ? Colors.red : null), onPressed: toggleVoice),
          IconButton(icon: const Icon(Icons.send), onPressed: sendText),
        ])),
      ]),
    );
  }
}
