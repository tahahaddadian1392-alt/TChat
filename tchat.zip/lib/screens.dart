import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';

String _email(String id) => '${id.toLowerCase()}@tchat.app';

// ---------- ورود / ثبت‌نام ----------
class AuthScreen extends StatefulWidget { const AuthScreen({super.key}); @override State<AuthScreen> createState() => _A(); }
class _A extends State<AuthScreen> {
  final id = TextEditingController(), pw = TextEditingController();
  bool signup = false; String? err;

  Future<void> go() async {
    try {
      if (signup) {
        if (await sb.rpc('user_id_exists', params: {'u': id.text.trim()})) {
          setState(() => err = app.t('taken')); return;
        }
        await sb.auth.signUp(email: _email(id.text.trim()), password: pw.text,
            data: {'user_id': id.text.trim()});
      } else {
        await sb.auth.signInWithPassword(email: _email(id.text.trim()), password: pw.text);
      }
      await app.refreshMe();
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) { setState(() => err = e.toString()); }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 110, height: 110)),
          const SizedBox(height: 24),
          TextField(controller: id, decoration: InputDecoration(labelText: app.t('userid'))),
          TextField(controller: pw, obscureText: true, decoration: InputDecoration(labelText: app.t('pass'))),
          if (err != null) Padding(padding: const EdgeInsets.all(8), child: Text(err!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          FilledButton(onPressed: go, child: Text(app.t(signup ? 'signup' : 'login'))),
          TextButton(onPressed: () => setState(() => signup = !signup), child: Text(app.t(signup ? 'login' : 'signup'))),
        ])),
      );
}

// ---------- لیست چت‌ها ----------
class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _H(); }
class _H extends State<HomeScreen> {
  bool held = false; int taps = 0; DateTime last = DateTime(2000);
  List<Map<String, dynamic>> chats = [];

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final r = await sb.from('chats').select('id,type,title,chat_members(profiles(user_id,display_name))');
    setState(() => chats = List<Map<String, dynamic>>.from(r));
  }

  String name(Map c) {
    if (c['type'] == 'group') return c['title'] ?? 'Group';
    final m = (c['chat_members'] as List).map((e) => e['profiles']).firstWhere(
        (p) => p['user_id'] != app.me!['user_id'], orElse: () => {'user_id': '?'});
    return m['user_id'];
  }

  // مخفی: نگه داشتن تنظیمات + سه ضربه روی عکس پروفایل
  void avatarTap() {
    if (!held) return;
    final now = DateTime.now();
    taps = now.difference(last).inSeconds < 2 ? taps + 1 : 1;
    last = now;
    if (taps >= 3) { taps = 0; askCode(); }
  }

  Future<void> askCode() async {
    final ctl = TextEditingController();
    final code = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      content: TextField(controller: ctl, keyboardType: TextInputType.number, maxLength: 6,
          obscureText: true, decoration: InputDecoration(labelText: app.t('pass6'))),
      actions: [TextButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(app.t('ok')))]));
    if (code == null) return;
    try { await sb.rpc('claim_owner', params: {'pass': code}); } catch (_) {}
    await app.refreshMe();
  }

  Future<void> newChat() async {
    final ctl = TextEditingController();
    final id = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      content: TextField(controller: ctl, decoration: InputDecoration(labelText: app.t('newchat'))),
      actions: [TextButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(app.t('ok')))]));
    if (id == null || id.isEmpty) return;
    final cid = await sb.rpc('get_or_create_direct', params: {'other': id.trim()});
    if (mounted) await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: cid, title: id)));
    load();
  }

  @override
  Widget build(BuildContext c) {
    final av = app.me?['avatar_url'];
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(
            colors: app.turq ? [turquoise, const Color(0xFF2A7DE1)] : [Theme.of(c).colorScheme.primaryContainer, Theme.of(c).colorScheme.primaryContainer]))),
        title: const Text('TChat'),
        leading: Padding(padding: const EdgeInsets.all(8), child: GestureDetector(onTap: avatarTap,
            child: CircleAvatar(backgroundImage: av != null ? NetworkImage(av) : null, child: av == null ? const Icon(Icons.person) : null))),
        actions: [
          Listener(
            onPointerDown: (_) => held = true,
            onPointerUp: (_) => held = false,
            onPointerCancel: (_) => held = false,
            child: IconButton(icon: const Icon(Icons.settings),
                onPressed: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => const SettingsScreen())); setState(() {}); }),
          ),
        ],
      ),
      body: RefreshIndicator(onRefresh: load, child: ListView(children: [
        for (final ch in chats) ListTile(
          leading: CircleAvatar(child: Icon(ch['type'] == 'group' ? Icons.group : Icons.person)),
          title: Text(name(ch)),
          onTap: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => ChatScreen(chatId: ch['id'], title: name(ch)))); },
        )
      ])),
      floatingActionButton: FloatingActionButton(onPressed: newChat, child: const Icon(Icons.edit)),
    );
  }
}

// ---------- تنظیمات و تم ----------
class SettingsScreen extends StatefulWidget { const SettingsScreen({super.key}); @override State<SettingsScreen> createState() => _S(); }
class _S extends State<SettingsScreen> {
  Future<void> pickAvatar() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 512);
    if (x == null) return;
    final path = 'avatars/${sb.auth.currentUser!.id}.jpg';
    await sb.storage.from('media').upload(path, File(x.path), fileOptions: const FileOptions(upsert: true));
    final url = sb.storage.from('media').getPublicUrl(path);
    await sb.from('profiles').update({'avatar_url': '$url?t=${DateTime.now().millisecondsSinceEpoch}'}).eq('id', sb.auth.currentUser!.id);
    await app.refreshMe(); setState(() {});
  }

  Future<void> proDialog() async => showDialog(context: context, builder: (c) => AlertDialog(
        title: Text(app.t('proTitle')), content: Text(app.t('proMsg')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: Text(app.t('close'))),
          FilledButton.icon(icon: const Icon(Icons.support_agent), label: Text(app.t('support')), onPressed: () async {
            Navigator.pop(c);
            final owner = await sb.rpc('get_owner_user_id');
            if (owner == null) return;
            final cid = await sb.rpc('get_or_create_direct', params: {'other': owner});
            if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: cid, title: owner)));
          }),
        ]));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(app.t('settings'))),
        body: ListView(children: [
          ListTile(leading: const Icon(Icons.photo_camera), title: Text(app.me?['user_id'] ?? ''), onTap: pickAvatar),
          ListTile(title: Text(app.t('mode'))),
          RadioListTile(title: Text(app.t('auto')), value: ThemeMode.system, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          RadioListTile(title: Text(app.t('light')), value: ThemeMode.light, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          RadioListTile(title: Text(app.t('dark')), value: ThemeMode.dark, groupValue: app.mode, onChanged: (v) { app.setMode(v!); setState(() {}); }),
          const Divider(),
          ListTile(title: Text(app.t('theme'))),
          ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFF2A7DE1)),
            title: const Text('Classic'), trailing: app.turq ? null : const Icon(Icons.check),
            onTap: () { app.setTurq(false); setState(() {}); }),
          ListTile(
            leading: Container(width: 40, height: 40, decoration: const BoxDecoration(shape: BoxShape.circle,
                gradient: LinearGradient(colors: [turquoise, Color(0xFF2A7DE1)]))),
            title: Text(app.t('turq')),
            trailing: app.isPro ? (app.turq ? const Icon(Icons.check) : null) : const Icon(Icons.lock),
            onTap: () { if (app.isPro) { app.setTurq(true); setState(() {}); } else { proDialog(); } }),
          const Divider(),
          ListTile(title: Text(app.t('lang')), trailing: Text(app.lang == 'fa' ? 'فارسی' : 'English'),
              onTap: () { app.setLang(app.lang == 'fa' ? 'en' : 'fa'); setState(() {}); }),
        ]),
      );
}

// ---------- صفحه چت ----------
class ChatScreen extends StatefulWidget {
  final String chatId, title;
  const ChatScreen({super.key, required this.chatId, required this.title});
  @override State<ChatScreen> createState() => _C();
}
class _C extends State<ChatScreen> {
  final ctl = TextEditingController();
  final rec = AudioRecorder();
  bool recording = false;

  Future<void> send(String kind, {String? body, String? url}) async {
    await sb.rpc('send_message', params: {'p_chat': widget.chatId, 'p_kind': kind, 'p_body': body, 'p_url': url});
    if (kind == 'text') await app.refreshMe(); // اگه پیام خاص بود وضعیت خودم هم به‌روز بشه
  }

  Future<void> sendText() async {
    final t = ctl.text.trim(); if (t.isEmpty) return;
    ctl.clear(); await send('text', body: t);
  }

  Future<String> upload(File f, String name) async {
    final path = '${widget.chatId}/${DateTime.now().millisecondsSinceEpoch}_$name';
    await sb.storage.from('media').upload(path, f);
    return sb.storage.from('media').getPublicUrl(path);
  }

  Future<void> attach() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null) return;
    final f = r.files.single; final ext = (f.extension ?? '').toLowerCase();
    final kind = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext) ? 'image'
        : ['mp4', 'mov', 'mkv', 'webm'].contains(ext) ? 'video' : 'file';
    await send(kind, body: f.name, url: await upload(File(f.path!), f.name));
  }

  Future<void> toggleVoice() async {
    if (!recording) {
      if (!await rec.hasPermission()) return;
      final dir = await getTemporaryDirectory();
      await rec.start(const RecordConfig(), path: '${dir.path}/v_${DateTime.now().millisecondsSinceEpoch}.m4a');
      setState(() => recording = true);
    } else {
      final p = await rec.stop(); setState(() => recording = false);
      if (p != null) await send('voice', url: await upload(File(p), 'voice.m4a'));
    }
  }

  Widget bubble(Map m) {
    final mine = m['sender'] == sb.auth.currentUser!.id;
    final k = m['kind'];
    Widget child = k == 'text' ? Text(m['body'] ?? '')
        : k == 'image' ? Image.network(m['media_url'], width: 220)
        : Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(k == 'voice' ? Icons.mic : k == 'video' ? Icons.videocam : Icons.insert_drive_file),
            const SizedBox(width: 6), Text(m['body'] ?? k)]);
    final cs = Theme.of(context).colorScheme;
    return Align(alignment: mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
        child: Container(margin: const EdgeInsets.all(4), padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: mine ? cs.primaryContainer : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(14)),
            child: child));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Column(children: [
          Expanded(child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: sb.from('messages').stream(primaryKey: ['id']).eq('chat_id', widget.chatId).order('created_at'),
            builder: (_, s) => ListView(children: [for (final m in s.data ?? []) bubble(m)]))),
          SafeArea(child: Row(children: [
            IconButton(icon: const Icon(Icons.attach_file), onPressed: attach),
            Expanded(child: TextField(controller: ctl, decoration: InputDecoration(hintText: app.t('msg')), onSubmitted: (_) => sendText())),
            IconButton(icon: Icon(recording ? Icons.stop_circle : Icons.mic, color: recording ? Colors.red : null), onPressed: toggleVoice),
            IconButton(icon: const Icon(Icons.send), onPressed: sendText),
          ])),
        ]),
      );
}
