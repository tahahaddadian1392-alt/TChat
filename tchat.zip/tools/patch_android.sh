#!/usr/bin/env bash
# اجرا بعد از flutter create — همه تنظیمات اندروید اینجاست
set -e
M=android/app/src/main/AndroidManifest.xml
sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <uses-permission android:name="android.permission.VIBRATE"/>\n    <uses-permission android:name="android.permission.WAKE_LOCK"/>\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>' $M
sed -i 's/android:label="tchat"/android:label="TChat"/' $M
sed -i '/<\/application>/i\        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService" android:foregroundServiceType="dataSync" android:exported="false" />' $M
# desugaring برای flutter_local_notifications
if [ -f android/app/build.gradle.kts ]; then
  sed -i 's/compileOptions {/compileOptions {\n        isCoreLibraryDesugaringEnabled = true/' android/app/build.gradle.kts
  printf '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n' >> android/app/build.gradle.kts
else
  sed -i 's/compileOptions {/compileOptions {\n        coreLibraryDesugaringEnabled true/' android/app/build.gradle
  printf "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n" >> android/app/build.gradle
fi
sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 23/; s/minSdkVersion flutter.minSdkVersion/minSdkVersion 23/' android/app/build.gradle* || true
if [ -f android/build.gradle.kts ]; then
cat >> android/build.gradle.kts <<'EOF'

subprojects {
    val fixSdk = { p: Project ->
        if (p.name != "app") {
            val ext = p.extensions.findByName("android")
            if (ext != null) {
                val cur = ext.javaClass.methods.firstOrNull { it.name == "getCompileSdk" && it.parameterCount == 0 }?.invoke(ext) as? Int
                if (cur == null || cur < 36) {
                    ext.javaClass.methods.firstOrNull { it.name == "setCompileSdk" && it.parameterCount == 1 }?.invoke(ext, 36)
                }
            }
        }
    }
    if (state.executed) fixSdk(this) else afterEvaluate { fixSdk(this) }
}
EOF
else
cat >> android/build.gradle <<'EOF'

subprojects {
    def fixSdk = { p ->
        if (p.name != 'app' && p.plugins.hasPlugin('com.android.library')) {
            p.android.compileSdkVersion 36
        }
    }
    if (state.executed) fixSdk(it) else afterEvaluate { fixSdk(it) }
}
EOF
fi
