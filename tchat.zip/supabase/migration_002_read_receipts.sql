-- ===== مهاجرت ۲: خوانده‌شدن پیام‌ها (تیک‌ها + نقطه سبز) =====
-- اگر قبلاً schema.sql رو اجرا کردی، فقط همین فایل رو در SQL Editor اجرا کن.
create table if not exists chat_reads(
  chat_id uuid references chats on delete cascade,
  member uuid references profiles on delete cascade,
  last_read_at timestamptz not null default now(),
  primary key(chat_id, member));
alter table chat_reads enable row level security;
drop policy if exists cr_read on chat_reads;
create policy cr_read on chat_reads for select to authenticated using (is_member(chat_id));

create or replace function mark_read(p_chat uuid) returns void language plpgsql security definer as $$
begin
  if not is_member(p_chat) then return; end if;
  insert into chat_reads(chat_id, member, last_read_at) values(p_chat, auth.uid(), clock_timestamp())
  on conflict(chat_id, member) do update set last_read_at = excluded.last_read_at;
end $$;

create or replace function unread_chats() returns table(chat_id uuid, cnt bigint)
language sql security definer stable as $$
  select m.chat_id, count(*) from messages m
  join chat_members cm on cm.chat_id = m.chat_id and cm.member = auth.uid()
  left join chat_reads r on r.chat_id = m.chat_id and r.member = auth.uid()
  where m.sender <> auth.uid() and m.created_at > coalesce(r.last_read_at, '-infinity')
  group by m.chat_id $$;

-- Realtime برای پیام‌ها و خواندن‌ها
do $$ begin
  begin alter publication supabase_realtime add table messages; exception when others then null; end;
  begin alter publication supabase_realtime add table chat_reads; exception when others then null; end;
end $$;
