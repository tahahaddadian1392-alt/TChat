-- TChat backend. در SQL Editor سوپابیس اجرا کن.
create extension if not exists pgcrypto;

create table profiles(
  id uuid primary key references auth.users on delete cascade,
  user_id text unique not null check (user_id ~ '^[a-zA-Z0-9_]{3,20}$'),
  display_name text, avatar_url text,
  role text not null default 'user' check (role in ('user','mod','owner')),
  is_pro boolean not null default false,
  created_at timestamptz default now());

create table chats(id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('direct','group')), title text,
  created_by uuid references profiles, created_at timestamptz default now());
create table chat_members(chat_id uuid references chats on delete cascade,
  member uuid references profiles on delete cascade, primary key(chat_id,member));
create table messages(id uuid primary key default gen_random_uuid(),
  chat_id uuid references chats on delete cascade, sender uuid references profiles,
  kind text not null check (kind in ('text','image','voice','video','file')),
  body text, media_url text, created_at timestamptz default now());

-- رمز مدیر فقط هش‌شده و بدون هیچ policy (از کلاینت قابل خوندن نیست)
create table app_secrets(key text primary key, value text not null);
insert into app_secrets values('owner_pass', crypt('641229', gen_salt('bf')));
create table pass_attempts(uid uuid, at timestamptz default now());
alter table app_secrets enable row level security;
alter table pass_attempts enable row level security;

alter table profiles enable row level security;
alter table chats enable row level security;
alter table chat_members enable row level security;
alter table messages enable row level security;

create function is_member(c uuid) returns boolean language sql security definer stable
as $$ select exists(select 1 from chat_members where chat_id=c and member=auth.uid()) $$;

create policy p_read on profiles for select to authenticated using (true);
create policy p_upd on profiles for update to authenticated using (id=auth.uid());
revoke update on profiles from authenticated;
grant update(display_name, avatar_url) on profiles to authenticated;
create policy c_read on chats for select to authenticated using (is_member(id));
create policy m_read on chat_members for select to authenticated using (is_member(chat_id));
create policy msg_read on messages for select to authenticated using (is_member(chat_id));
-- نوشتن در پیام‌ها فقط از طریق send_message

-- ساخت پروفایل بعد از ثبت‌نام (user_id در metadata)
create function on_signup() returns trigger language plpgsql security definer as $$
begin
  insert into profiles(id,user_id,display_name)
  values(new.id, new.raw_user_meta_data->>'user_id', new.raw_user_meta_data->>'user_id');
  return new;
end $$;
create trigger t_signup after insert on auth.users for each row execute function on_signup();

create function user_id_exists(u text) returns boolean language sql security definer
as $$ select exists(select 1 from profiles where lower(user_id)=lower(u)) $$;
grant execute on function user_id_exists to anon, authenticated;

-- چت خصوصی (یا برگردوندن چت موجود)
create function get_or_create_direct(other text) returns uuid language plpgsql security definer as $$
declare o uuid; c uuid;
begin
  select id into o from profiles where lower(user_id)=lower(other);
  if o is null then raise exception 'user_not_found'; end if;
  select cm1.chat_id into c from chat_members cm1 join chat_members cm2 using(chat_id)
    join chats ch on ch.id=cm1.chat_id
    where ch.type='direct' and cm1.member=auth.uid() and cm2.member=o limit 1;
  if c is null then
    insert into chats(type,created_by) values('direct',auth.uid()) returning id into c;
    insert into chat_members values(c,auth.uid()),(c,o);
  end if;
  return c;
end $$;

create function create_group(title text, members text[]) returns uuid language plpgsql security definer as $$
declare c uuid;
begin
  insert into chats(type,title,created_by) values('group',title,auth.uid()) returning id into c;
  insert into chat_members values(c,auth.uid());
  insert into chat_members select c,id from profiles where lower(user_id)=any(select lower(x) from unnest(members) x)
    on conflict do nothing;
  return c;
end $$;

-- آیدی سازنده برای دکمه پشتیبانی
create function get_owner_user_id() returns text language sql security definer
as $$ select user_id from profiles where role='owner' limit 1 $$;

-- ورود به حالت سازنده با رمز ۶ رقمی (فقط یک سازنده، حداکثر ۵ تلاش در ساعت)
create function claim_owner(pass text) returns boolean language plpgsql security definer as $$
begin
  if (select count(*) from pass_attempts where uid=auth.uid() and at>now()-interval '1 hour')>=5
    then raise exception 'too_many_attempts'; end if;
  if exists(select 1 from profiles where role='owner') then return false; end if;
  if (select value from app_secrets where key='owner_pass') = crypt(pass,(select value from app_secrets where key='owner_pass')) then
    update profiles set role='owner' where id=auth.uid(); return true;
  end if;
  insert into pass_attempts(uid) values(auth.uid()); return false;
end $$;

-- ارسال پیام + پیام‌های خاص (همه چیز سمت سرور)
create function send_message(p_chat uuid, p_kind text, p_body text, p_url text default null)
returns void language plpgsql security definer as $$
declare me profiles; other uuid; t text := trim(coalesce(p_body,''));
begin
  if not is_member(p_chat) then raise exception 'not_member'; end if;
  select * into me from profiles where id=auth.uid();
  if p_kind='text' and t in ('ACTIVE.PRO.6161','DEACTIVE.PRO.6262','ACTIVE.MOD.6060')
     and me.role in ('mod','owner')
     and (select type from chats where id=p_chat)='direct' then
    select member into other from chat_members where chat_id=p_chat and member<>auth.uid();
    if t='ACTIVE.PRO.6161' then update profiles set is_pro=true where id=other;
    elsif t='DEACTIVE.PRO.6262' then update profiles set is_pro=false where id=other;
    elsif t='ACTIVE.MOD.6060' and me.role='owner'
      then update profiles set role='mod' where id=other and role='user'; end if;
    return; -- پیام ذخیره و نمایش داده نمی‌شه
  end if;
  insert into messages(chat_id,sender,kind,body,media_url) values(p_chat,auth.uid(),p_kind,p_body,p_url);
end $$;

-- فایل‌ها و عکس‌ها: bucket عمومی به اسم media بساز و این policy رو بذار
-- create policy up on storage.objects for insert to authenticated with check (bucket_id='media');
-- عوض کردن عکس پروفایل (upsert روی فایل موجود) به policy آپدیت هم نیاز دارد:
-- create policy upd on storage.objects for update to authenticated using (bucket_id='media') with check (bucket_id='media');
-- و برای خواندن/نمایش عکس‌ها باید bucket مدیا Public باشد.
